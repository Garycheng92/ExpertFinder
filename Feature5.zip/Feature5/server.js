const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const env = require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

//parse application
app.use(bodyParser.urlencoded({ extended: false }))
//parse application/json
app.use(bodyParser.json())

app.listen(PORT, () => {
  console.log("You are listening on port " + "" + PORT)
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname + '/home.html'));
});

app.get('/home.html', (req, res) => {
  res.sendFile(path.join(__dirname + '/home.html'));
});

app.get('/Feature2.html', (req, res) => {
  res.sendFile(path.join(__dirname + '/Feature2.html'));
});

app.get('/Feature2_expertlist.html', (req, res) => {
  res.sendFile(path.join(__dirname + '/Feature2_expertlist.html'));
});

app.get('/Feature2_no_results.html', (req, res) => {
  res.sendFile(path.join(__dirname + '/Feature2_no_results.html'));
});

app.get('/Feature3.html', (req, res) => {
  res.sendFile(path.join(__dirname + '/Feature3.html'));
});

app.get('/Feature5.html', (req, res) => {
  res.sendFile(path.join(__dirname + '/Feature5.html'));
  console.log("This is the form that shows")
});

app.post('/Feature5.html', (req, res) => {
  "use strict";

// async..await is not allowed in global scope, must use a wrapper
async function main() {

  // create reusable transporter object using the default SMTP transport
  let transporter = nodemailer.createTransport({
    service: 'gmail', // true for 465, false for other ports
    auth: {
      user: 'expertFinder123123@gmail.com', // generated ethereal user
      pass: '123456789!@#' // generated ethereal password
    }
  });

  //*******login to gmail account.
  //       go to account
  //       turn ON Less secure app access
  //       after this when you try to send mail from your app you will get error .
  //       than go to Security issues found ( it's first option in security tab of google account )
  //****** here you need to verify that last activities is verified and its you .
   
  // send mail with defined transport object
  let info = await transporter.sendMail({
    from: 'expertFinder123123@gmail.com', // sender address 
    to: `${req.body.email}`, // email based on user input 
    subject: "Verify your expertFinder registration", // Subject line
    html: `<h1> Welcome to expertFinder!<h1>
    	   <p>You are receiving this email because it was used to sign up for expertFinder.</p>	
	       <p>Signed Up As: ${req.body.signup}<br>
	          First Name: ${req.body.firstname}<br>
     		    Last Name: ${req.body.lastname}<br>
       		  Gender: ${req.body.gender}<br>
       		  Phone: ${req.body.phone}<br>
	   		    Email: ${req.body.email}<br>
       		  Tech Skillset: ${req.body.techskillset}<br>
       		  Past Courses: ${req.body.pastcourses}<br>
       		  Industry/Organization: ${req.body.industry}<br>
	          Github: ${req.body.github}<br>
            Twitter: ${req.body.twitter}<br>
            LinkedIn: ${req.body.LinkedIn}</p>
		     <p><a href="http://localhost:3000/Feature3.html">Click here to activate your account</a></p>`
  });

  console.log("Email sent successfully!");
  // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>
}

main().catch(console.error);  

});
