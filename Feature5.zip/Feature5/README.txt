Feature 5: the users are able to register and receive a confirmation email(gmail only)
           to the email they entered in Feature5.html.

To run: node server.js
        go to localhost:3000
	go to localhost:3000/Feature5.html or click on register in navbar 
	fill out form
	email must be gmail
	enter submit(still need to work on redirecting to home)
	check the email you signed up with(make sure to check spam folder as well)
	click on the link to activate account
	Redirects to Feature3.html

	
